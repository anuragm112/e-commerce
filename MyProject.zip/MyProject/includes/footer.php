<!doctype html>
<html>
    <head>
        <title>Lifestyle Store</title>
  <?php include'links.php';
  ?>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            footer{
                 background-color: #000;
              color:#fff;
             font-size:14px;
              margin-top: 100px;
            }
            
        </style>
    </head>
    
    <body>
        <footer>  
        <div class="container">
            <center>
        <p>Copyright &copy; Lifestyle Store. All Rights Reserved  |  Contact Us: +91 90000 00000</p>
            </center>
        </div>
        </footer>
    </body>  
</html>    
